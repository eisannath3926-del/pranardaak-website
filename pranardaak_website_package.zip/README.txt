Pranar Daak - Website package (PROTOTYPE)
Files:
- package.json : basic Vite React project
- public/index.html
- src/main.jsx
- src/App.jsx : React single-file prototype (localStorage demo)
- simple-booking.html : A simple single-file fallback booking page (can be uploaded alone to GitHub)
How to use:
- If you want the simple route: upload 'simple-booking.html' in GitHub (Add file -> Upload files). This single file will act as a basic booking page and can be served.
- For full React app: extract files and run 'npm install' then 'npm run dev' (requires Node).
