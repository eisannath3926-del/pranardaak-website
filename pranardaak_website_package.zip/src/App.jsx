import React, { useEffect, useState, useRef } from "react";

/*
Pranar Daak — Full Booking & Booking Management (Single-file React prototype)
This is the same prototype code provided earlier in the conversation.
It uses localStorage for demo. For production, connect Firebase and notification services.
*/
const uid = () => Math.random().toString(36).slice(2, 9);
const nowISO = () => new Date().toISOString();
const parseDMY = (s) => {
  const [d, m, y] = (s || "").split("/").map((x) => Number(x));
  if (!d || !m || !y) return null;
  return new Date(y, m - 1, d);
};
const addDays = (date, days) => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
};
const LS = {
  SITE: "pdb_site_v2",
  MEMBERS: "pdb_members_v2",
  BOOKINGS: "pdb_bookings_v2",
  NOTIFS: "pdb_notifs_v2",
  ADMIN: "pdb_admin_v2",
  PAYQR: "pdb_payqr_v2",
};
function init() {
  if (!localStorage.getItem(LS.SITE)) {
    localStorage.setItem(
      LS.SITE,
      JSON.stringify({
        name: "Pranar Daak Band",
        domain: "pranardaak.vercel.app",
        description: "Professional band booking — Pranar Daak",
        adminEmail: "eisannath3926@gmail.com",
        depositDefaultOn: true,
        depositPercent: 50,
      })
    );
  }
  if (!localStorage.getItem(LS.MEMBERS)) {
    localStorage.setItem(
      LS.MEMBERS,
      JSON.stringify([
        {
          id: uid(),
          name: "Demo Singer",
          role: "Singer",
          phone: "",
          email: "",
          code: "3926",
          availableDates: [],
          fee: 2000,
          canEditFee: true,
          photo: null,
          createdAt: nowISO(),
        },
      ])
    );
  }
  if (!localStorage.getItem(LS.BOOKINGS)) {
    localStorage.setItem(LS.BOOKINGS, JSON.stringify([]));
  }
  if (!localStorage.getItem(LS.NOTIFS)) {
    localStorage.setItem(LS.NOTIFS, JSON.stringify([]));
  }
  if (!localStorage.getItem(LS.ADMIN)) {
    localStorage.setItem(LS.ADMIN, JSON.stringify({ passcode: "3926" }));
  }
  if (!localStorage.getItem(LS.PAYQR)) {
    localStorage.setItem(LS.PAYQR, JSON.stringify({ qrDataURL: null }));
  }
}
init();
function read(key) {
  return JSON.parse(localStorage.getItem(key));
}
function write(key, val) {
  localStorage.setItem(key, JSON.stringify(val));
}
function pushNotif(msg) {
  const n = read(LS.NOTIFS) || [];
  n.unshift({ id: uid(), msg, time: nowISO() });
  write(LS.NOTIFS, n);
}
async function notifyServerWebhook(payload) {
  try {
    await fetch("/api/notify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    console.warn("notify webhook failed (frontend prototype)", e);
  }
}
export default function App() {
  const [site, setSite] = useState(read(LS.SITE));
  const [members, setMembers] = useState(read(LS.MEMBERS));
  const [bookings, setBookings] = useState(read(LS.BOOKINGS));
  const [notifs, setNotifs] = useState(read(LS.NOTIFS));
  const [payQR, setPayQR] = useState(read(LS.PAYQR));
  const [adminCfg, setAdminCfg] = useState(read(LS.ADMIN));
  const [view, setView] = useState("home");
  const [adminSession, setAdminSession] = useState(false);
  const [memberSession, setMemberSession] = useState(null);
  const tickRef = useRef(null);
  useEffect(() => {
    const onStorage = () => {
      setSite(read(LS.SITE));
      setMembers(read(LS.MEMBERS));
      setBookings(read(LS.BOOKINGS));
      setNotifs(read(LS.NOTIFS));
      setPayQR(read(LS.PAYQR));
      setAdminCfg(read(LS.ADMIN));
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);
  useEffect(() => {
    function runChecks() {
      const bs = read(LS.BOOKINGS) || [];
      const changed = [];
      const now = new Date();
      bs.forEach((b) => {
        if (b.status === "confirmed" && b.depositRequired) {
          const due = new Date(b.depositDueAt);
          if (now > due && !(b.payments && b.payments.some((p) => p.amount >= b.depositAmount))) {
            b.status = "cancelled_system_unpaid";
            b.cancelledAt = nowISO();
            pushNotif(`Booking ${b.id} auto-cancelled due to unpaid deposit`);
            notifyServerWebhook({ type: "booking_cancelled_auto", booking: b, adminEmail: site.adminEmail });
            changed.push(b);
          }
        }
        const evDate = parseDMY(b.eventDate);
        if (b.status === "confirmed" && evDate && now > addDays(evDate, 1)) {
          b.status = "completed";
          b.completedAt = nowISO();
          changed.push(b);
        }
      });
      if (changed.length) {
        const next = bs.map((x) => (changed.find((c) => c.id === x.id) ? changed.find((c) => c.id === x.id) : x));
        write(LS.BOOKINGS, next);
        setBookings(next);
      }
    }
    tickRef.current = setInterval(runChecks, 30 * 1000);
    return () => clearInterval(tickRef.current);
  }, [site]);
  function saveMembers(next) {
    write(LS.MEMBERS, next);
    setMembers(next);
  }
  function saveBookings(next) {
    write(LS.BOOKINGS, next);
    setBookings(next);
  }
  function saveSite(next) {
    write(LS.SITE, next);
    setSite(next);
  }
  function savePayQR(next) {
    write(LS.PAYQR, next);
    setPayQR(next);
  }
  function saveAdmin(next) {
    write(LS.ADMIN, next);
    setAdminCfg(next);
  }
  function adminLogin(pass) {
    const cfg = read(LS.ADMIN) || { passcode: "3926" };
    if (pass === cfg.passcode) {
      setAdminSession(true);
      return true;
    }
    return false;
  }
  function adminLogout() {
    setAdminSession(false);
    setView("home");
  }
  function adminCreateMember(m) {
    const list = read(LS.MEMBERS) || [];
    if (list.find((x) => x.code === m.code)) return { ok: false, message: "Code used" };
    const mm = { id: uid(), ...m, createdAt: nowISO() };
    const next = [mm, ...list];
    saveMembers(next);
    pushNotif(`Member created: ${m.name}`);
    return { ok: true, member: mm };
  }
  function adminUpdateMember(id, patch) {
    const list = read(LS.MEMBERS) || [];
    const next = list.map((x) => (x.id === id ? { ...x, ...patch } : x));
    saveMembers(next);
    return true;
  }
  function adminDeleteMember(id) {
    if (!window.confirm("Delete member?")) return;
    const next = members.filter((m) => m.id !== id);
    saveMembers(next);
  }
  function adminSetFee(id, fee) {
    const next = members.map((m) => (m.id === id ? { ...m, fee } : m));
    saveMembers(next);
  }
  function adminAddTravelFee(bookingId, travelFee) {
    const bs = read(LS.BOOKINGS) || [];
    const next = bs.map((b) => (b.id === bookingId ? { ...b, travelFee, total: Number(b.subtotal || 0) + Number(travelFee || 0) } : b));
    saveBookings(next);
    pushNotif(`Travel fee added to booking ${bookingId}`);
    notifyServerWebhook({ type: "travel_fee_added", bookingId, travelFee });
  }
  function adminCancelBooking(bookingId, reason = "Cancelled by admin") {
    const bs = read(LS.BOOKINGS) || [];
    const next = bs.map((b) => (b.id === bookingId ? { ...b, status: "cancelled_admin", cancelledAt: nowISO(), cancelReason: reason } : b));
    saveBookings(next);
    pushNotif(`Booking ${bookingId} cancelled by admin`);
    notifyServerWebhook({ type: "booking_cancelled_admin", bookingId });
  }
  function adminUploadQR(file) {
    const reader = new FileReader();
    reader.onload = () => {
      savePayQR({ qrDataURL: reader.result });
      pushNotif("Payment QR uploaded");
    };
    reader.readAsDataURL(file);
  }
  function memberLogin(code) {
    const m = (read(LS.MEMBERS) || []).find((x) => x.code === code);
    if (!m) return { ok: false };
    setMemberSession(m.id);
    return { ok: true, member: m };
  }
  function memberLogout() {
    setMemberSession(null);
    setView("home");
  }
  function memberUpdateSelf(id, patch) {
    const list = read(LS.MEMBERS) || [];
    const next = list.map((x) => (x.id === id ? { ...x, ...patch } : x));
    saveMembers(next);
  }
  function createBooking(form) {
    if (!form.name || !form.phone || !form.eventDate) return { ok: false, message: "Name, phone and date required" };
    if (!form.selectedMemberIds || form.selectedMemberIds.length === 0) return { ok: false, message: "Select at least one performer" };
    const ms = read(LS.MEMBERS) || [];
    const selected = form.selectedMemberIds.map((id) => ms.find((m) => m.id === id)).filter(Boolean);
    const subtotal = selected.reduce((s, m) => s + Number(m.fee || 0), 0);
    const siteCfg = read(LS.SITE) || {};
    const depositDefaultOn = siteCfg.depositDefaultOn !== undefined ? siteCfg.depositDefaultOn : true;
    const depositPercent = siteCfg.depositPercent || 50;
    const bookedAt = new Date();
    const eventDateObj = parseDMY(form.eventDate);
    let depositDueAt = null;
    let depositAmount = 0;
    const depositRequired = Boolean(depositDefaultOn);
    if (depositRequired && eventDateObj) {
      const daysBetween = Math.max(1, Math.ceil((eventDateObj - bookedAt) / (1000 * 60 * 60 * 24)));
      const mid = Math.floor(daysBetween / 2);
      depositDueAt = addDays(bookedAt, mid).setHours(23, 59, 59, 0);
      depositAmount = Math.round((subtotal * depositPercent) / 100);
    }
    const b = {
      id: uid(),
      createdAt: nowISO(),
      name: form.name,
      phone: form.phone,
      email: form.email || null,
      eventDate: form.eventDate,
      eventTime: form.eventTime,
      address: form.address || null,
      landmark: form.landmark || null,
      selectedMemberIds: form.selectedMemberIds,
      subtotal,
      travelFee: 0,
      total: subtotal,
      status: "confirmed",
      depositRequired: depositRequired,
      depositPercent: depositPercent,
      depositDueAt: depositDueAt ? new Date(depositDueAt).toISOString() : null,
      depositAmount,
      payments: [],
      editEnabled: false,
    };
    const msNext = ms.map((m) => {
      if (b.selectedMemberIds.includes(m.id)) {
        const avr = m.availableDates || [];
        const newAv = avr.filter((d) => d !== b.eventDate);
        return { ...m, availableDates: newAv };
      }
      return m;
    });
    const bs = read(LS.BOOKINGS) || [];
    saveBookings([b, ...bs]);
    saveMembers(msNext);
    pushNotif(`New booking created: ${b.id}`);
    notifyServerWebhook({ type: "new_booking", booking: b, adminEmail: site.adminEmail });
    return { ok: true, booking: b };
  }
  function markPayment(bookingId, amount, txnRef) {
    const bs = read(LS.BOOKINGS) || [];
    const next = bs.map((b) => {
      if (b.id === bookingId) {
        const payments = [...(b.payments || []), { id: uid(), amount: Number(amount), txnRef, at: nowISO() }];
        const paid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
        const totalDue = Number(b.total || 0);
        const newStatus = paid >= totalDue ? "paid" : b.status;
        return { ...b, payments, paidAmount: paid, status: newStatus };
      }
      return b;
    });
    saveBookings(next);
    pushNotif(`Payment recorded for booking ${bookingId}`);
    notifyServerWebhook({ type: "payment_recorded", bookingId, amount });
  }
  function memberCancelParticipation(bookingId, memberId) {
    const bs = read(LS.BOOKINGS) || [];
    const ms = read(LS.MEMBERS) || [];
    const next = bs.map((b) => {
      if (b.id === bookingId) {
        if (!b.selectedMemberIds.includes(memberId)) return b;
        const newSelected = b.selectedMemberIds.filter((id) => id !== memberId);
        const member = ms.find((m) => m.id === memberId);
        const cancelLog = { who: memberId, at: nowISO() };
        const cancelLogs = [...(b.cancelLogs || []), cancelLog];
        return { ...b, selectedMemberIds: newSelected, cancelLogs, editEnabled: true };
      }
      return b;
    });
    saveBookings(next);
    pushNotif(`Member cancelled participation for booking ${bookingId}`);
    notifyServerWebhook({ type: "member_cancel", bookingId, memberId });
  }
  function userEditBookingReplace(bookingId, newMemberIds) {
    const bs = read(LS.BOOKINGS) || [];
    const ms = read(LS.MEMBERS) || [];
    const next = bs.map((b) => {
      if (b.id === bookingId && b.editEnabled) {
        const selected = newMemberIds.map((id) => ms.find((m) => m.id === id)).filter(Boolean);
        const subtotal = selected.reduce((s, m) => s + Number(m.fee || 0), 0);
        const total = Number(b.travelFee || 0) + subtotal;
        return { ...b, selectedMemberIds: newMemberIds, subtotal, total, editEnabled: false };
      }
      return b;
    });
    saveBookings(next);
    pushNotif(`Booking ${bookingId} edited by user`);
    notifyServerWebhook({ type: "booking_edited", bookingId });
  }
  function sendCancellationNotifications(booking) {
    notifyServerWebhook({ type: "booking_cancel_all", booking });
    pushNotif(`Notifications sent for cancelled booking ${booking.id}`);
  }
  function Header() {
    return (
      <header style={{ background: "#000", color: "#fff", padding: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ margin: 0 }}>{site.name}</h1>
            <div style={{ fontSize: 12, opacity: 0.8 }}>{site.description}</div>
          </div>
          <nav style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setView("home")}>Home</button>
            <button onClick={() => setView("book")}>Book</button>
            <button onClick={() => setView("gallery")}>Gallery</button>
            {memberSession ? <button onClick={() => setView("member")}>Member</button> : <button onClick={() => setView("memberLogin")}>Member Login</button>}
            {adminSession ? <button onClick={() => setView("admin")}>Admin</button> : <button onClick={() => setView("adminLogin")}>Owner Login</button>}
          </nav>
        </div>
      </header>
    );
  }
  function Home() {
    return (
      <div style={{ padding: 16 }}>
        <h2>Welcome to {site.name}</h2>
        <p>{site.description}</p>
        <section>
          <h3>Members</h3>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {members.map((m) => (
              <div key={m.id} style={{ border: "1px solid #ddd", padding: 8, width: 200 }}>
                <div style={{ height: 120, background: "#111", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {m.photo ? <img src={m.photo} alt="p" style={{ maxHeight: 120 }} /> : <div style={{ color: "#fff" }}>No Photo</div>}
                </div>
                <div style={{ marginTop: 8 }}>
                  <div style={{ fontWeight: "bold" }}>{m.name}</div>
                  <div style={{ fontSize: 12 }}>{m.role}</div>
                  <div style={{ fontSize: 12 }}>Fee: {m.fee || 0}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    );
  }
  function Gallery() {
    return (
      <div style={{ padding: 16 }}>
        <h3>Gallery</h3>
        <div>Upload photos/videos via Member panel (demo).</div>
      </div>
    );
  }
  function BookingForm() {
    const [form, setForm] = useState({ name: "", phone: "", email: "", eventDate: "", eventTime: "", address: "", landmark: "", selectedMemberIds: [] });
    const [msg, setMsg] = useState(null);
    function toggleMember(id) {
      const s = new Set(form.selectedMemberIds);
      if (s.has(id)) s.delete(id); else s.add(id);
      setForm({ ...form, selectedMemberIds: Array.from(s) });
    }
    const selectedMembers = form.selectedMemberIds.map((id) => members.find((m) => m.id === id)).filter(Boolean);
    const subtotal = selectedMembers.reduce((s, m) => s + Number(m.fee || 0), 0);
    async function onSubmit(e) {
      e.preventDefault();
      const res = createBooking(form);
      if (!res.ok) return setMsg({ type: "error", text: res.message });
      setMsg({ type: "success", text: `Booking created — ID ${res.booking.id}` });
      setForm({ name: "", phone: "", email: "", eventDate: "", eventTime: "", address: "", landmark: "", selectedMemberIds: [] });
      setView("home");
    }
    return (
      <div style={{ padding: 16 }}>
        <h3>Book Pranar Daak</h3>
        <form onSubmit={onSubmit} style={{ display: "grid", gap: 8, maxWidth: 720 }}>
          <label>Full name *
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </label>
          <label>Phone *
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </label>
          <label>Email (optional)
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </label>
          <label>Event Date (DD/MM/YYYY) *
            <input placeholder="DD/MM/YYYY" value={form.eventDate} onChange={(e) => setForm({ ...form, eventDate: e.target.value })} />
          </label>
          <label>Event Time (e.g. 07:30 PM) *
            <input placeholder="hh:mm AM/PM" value={form.eventTime} onChange={(e) => setForm({ ...form, eventTime: e.target.value })} />
          </label>
          <label>Address (or leave empty to use landmark)
            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </label>
          <label>Landmark (optional)
            <input value={form.landmark} onChange={(e) => setForm({ ...form, landmark: e.target.value })} />
          </label>
          <div style={{ padding: 8, background: "#f6f6f6" }}>
            <div style={{ fontSize: 13 }}>Choose performers (only Available will be addable)</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
              {members.map((m) => {
                const isAvailable = !m.availableDates || m.availableDates.length === 0 || (form.eventDate && m.availableDates.includes(form.eventDate));
                return (
                  <label key={m.id} style={{ border: "1px solid #ddd", padding: 8, minWidth: 180, opacity: isAvailable ? 1 : 0.5 }}>
                    <div style={{ fontWeight: "bold" }}>{m.name}</div>
                    <div style={{ fontSize: 12 }}>{m.role}</div>
                    <div style={{ fontSize: 12 }}>Fee: {m.fee || 0}</div>
                    <div><input type="checkbox" checked={form.selectedMemberIds.includes(m.id)} disabled={!isAvailable} onChange={() => toggleMember(m.id)} /></div>
                  </label>
                );
              })}
            </div>
          </div>
          <div style={{ padding: 8 }}>Subtotal: <strong>{subtotal}</strong></div>
          <div style={{ padding: 8, background: "#fff4e6", border: "1px solid #ffd" }}>
            <div style={{ fontWeight: "bold" }}>Important / গুরুত্বপূর্ণ</div>
            <div>English: "Travel cost will be added separately after checking the event location."</div>
            <div>বাংলা: "যাতায়াতের জন্য ফি আলাদা এবং সেটি লোকেশন দেখার পর যোগ করা হবে।"</div>
            <div style={{ marginTop: 8 }}>Also: 50% deposit may be required; you'll be informed about deposit due date after booking (admin can toggle).
            </div>
          </div>
          <div>
            <button type="submit">Confirm Booking</button>
            {msg && <div style={{ marginTop: 8 }}>{msg.text}</div>}
          </div>
        </form>
      </div>
    );
  }
  function MemberLogin() {
    const [code, setCode] = useState("");
    const [err, setErr] = useState(null);
    function onLogin(e) {
      e.preventDefault();
      const r = memberLogin(code);
      if (!r.ok) setErr("Invalid code"); else setView("member");
    }
    return (
      <div style={{ padding: 16 }}>
        <h3>Member Login</h3>
        <form onSubmit={onLogin}>
          <input placeholder="4-6 digit code" value={code} onChange={(e) => setCode(e.target.value)} />
          <div>
            <button>Login</button>
            <button type="button" onClick={() => setView("home")}>Cancel</button>
          </div>
          {err && <div style={{ color: "red" }}>{err}</div>}
        </form>
      </div>
    );
  }
  function MemberPanel() {
    const m = members.find((x) => x.id === memberSession);
    if (!m) return <div style={{ padding: 16 }}>Session lost. <button onClick={() => setView("memberLogin")}>Login</button></div>;
    const [editMode, setEditMode] = useState(false);
    const [form, setForm] = useState({ name: m.name, role: m.role, phone: m.phone, email: m.email, fee: m.fee });
    function save() {
      const patch = { name: form.name, role: form.role, phone: form.phone, email: form.email };
      if (m.canEditFee) patch.fee = Number(form.fee || 0);
      memberUpdateSelf(m.id, patch);
      setEditMode(false);
    }
    function uploadPhoto(file) {
      const r = new FileReader();
      r.onload = () => {
        memberUpdateSelf(m.id, { photo: r.result });
      };
      r.readAsDataURL(file);
    }
    function toggleAvailabilityDate(date) {
      const avr = m.availableDates || [];
      const set = new Set(avr);
      if (set.has(date)) set.delete(date); else set.add(date);
      memberUpdateSelf(m.id, { availableDates: Array.from(set) });
    }
    const myBookings = bookings.filter((b) => b.selectedMemberIds.includes(m.id));
    return (
      <div style={{ padding: 16 }}>
        <h3>Member Panel — {m.name}</h3>
        <div>
          <div>
            <strong>Profile</strong>
            <div>
              {m.photo ? <img src={m.photo} alt="me" style={{ maxWidth: 120 }} /> : <div>No Photo</div>}
              <div>
                <input type="file" accept="image/*" onChange={(e) => uploadPhoto(e.target.files[0])} />
                <button onClick={() => memberUpdateSelf(m.id, { photo: null })}>Remove Photo</button>
              </div>
            </div>
            {editMode ? (
              <div>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} />
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                {m.canEditFee && <input value={form.fee} onChange={(e) => setForm({ ...form, fee: e.target.value })} />}
                <div>
                  <button onClick={save}>Save</button>
                  <button onClick={() => setEditMode(false)}>Cancel</button>
                </div>
              </div>
            ) : (
              <div>
                <div>Name: {m.name}</div>
                <div>Role: {m.role}</div>
                <div>Phone: {m.phone}</div>
                <div>Email: {m.email}</div>
                <div>Fee: {m.fee}</div>
                <button onClick={() => setEditMode(true)}>Edit Profile</button>
              </div>
            )}
          </div>
          <div style={{ marginTop: 12 }}>
            <strong>Availability (add DD/MM/YYYY)</strong>
            <div>
              <input placeholder="DD/MM/YYYY" id="availDate" />
              <button onClick={() => {
                const d = document.getElementById("availDate").value;
                if (!d) return alert("enter date");
                toggleAvailabilityDate(d);
                document.getElementById("availDate").value = "";
              }}>Toggle Date</button>
            </div>
            <div>
              <strong>Your upcoming bookings:</strong>
              <div>
                {myBookings.map(b => (
                  <div key={b.id} style={{ border: "1px solid #eee", padding: 8, marginTop: 6 }}>
                    <div>Booking ID: {b.id}</div>

                    <div>Date: {b.eventDate} Time: {b.eventTime}</div>
                    <div>Location: {b.address} {b.landmark ? `, ${b.landmark}` : ''}</div>
                    <div>Status: {b.status}</div>
                    <div>
                      <button onClick={() => { if (!window.confirm('Cancel your participation?')) return; memberCancelParticipation(b.id, m.id); }}>Cancel Participation</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div style={{ marginTop: 12 }}>
            <button onClick={() => { memberLogout(); setView('home'); }}>Logout</button>
          </div>
        </div>
      </div>
    );
  }
  function AdminLogin() {
    const [pass, setPass] = useState("");
    const [err, setErr] = useState(null);
    function onLogin(e) {
      e.preventDefault();
      if (adminLogin(pass)) setView("admin"); else setErr("Wrong passcode");
    }
    return (
      <div style={{ padding: 16 }}>
        <h3>Owner / Admin Login</h3>
        <form onSubmit={onLogin}>
          <input placeholder="passcode" value={pass} onChange={(e) => setPass(e.target.value)} />
          <div>
            <button>Login</button>
            <button type="button" onClick={() => setView('home')}>Cancel</button>
          </div>
          {err && <div style={{ color: 'red' }}>{err}</div>}
        </form>
      </div>
    );
  }
  function AdminPanel() {
    const [tab, setTab] = useState('site');
    const cfg = read(LS.SITE);
    return (
      <div style={{ padding: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <h3>Admin Panel</h3>
          <div>
            <button onClick={() => { adminLogout(); }}>Logout</button>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => setTab('site')}>Site</button>
          <button onClick={() => setTab('members')}>Members</button>
          <button onClick={() => setTab('bookings')}>Bookings</button>
          <button onClick={() => setTab('notify')}>Notifications</button>
          <button onClick={() => setTab('payments')}>Payments</button>
        </div>
        <div style={{ marginTop: 12 }}>
          {tab === 'site' && <AdminSite />}
          {tab === 'members' && <AdminMembers />}
          {tab === 'bookings' && <AdminBookings />}
          {tab === 'notify' && <AdminNotifs />}
          {tab === 'payments' && <AdminPayments />}
        </div>
      </div>
    );
  }
  function AdminSite() {
    const [name, setName] = useState(site.name);
    const [desc, setDesc] = useState(site.description);
    const [depositOn, setDepositOn] = useState(site.depositDefaultOn);
    const [depositPercent, setDepositPercent] = useState(site.depositPercent || 50);
    function save() {
      const s = { ...site, name, description: desc, depositDefaultOn: depositOn, depositPercent };
      saveSite(s);
    }
    return (
      <div>
        <div>
          <label>Site name <input value={name} onChange={(e) => setName(e.target.value)} /></label>
        </div>
        <div>
          <label>Description <input value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
        </div>
        <div>
          <label>Default deposit required <input type="checkbox" checked={depositOn} onChange={(e) => setDepositOn(e.target.checked)} /></label>
        </div>
        <div>
          <label>Deposit percent <input value={depositPercent} onChange={(e) => setDepositPercent(Number(e.target.value))} /></label>
        </div>
        <div><button onClick={save}>Save</button></div>
      </div>
    );
  }
  function AdminMembers() {
    const [form, setForm] = useState({ name: '', role: 'Singer', phone: '', email: '', code: '', fee: 0, canEditFee: false });
    function genCode() {
      const c = Math.floor(1000 + Math.random() * 900000).toString().slice(0, Math.floor(4 + Math.random() * 3));
      setForm({ ...form, code: c });
    }
    function create() {
      if (!form.name || !form.code) return alert('name & code required');
      adminCreateMember(form);
      setForm({ name: '', role: 'Singer', phone: '', email: '', code: '', fee: 0, canEditFee: false });
    }
    return (
      <div>
        <h4>Create Member</h4>
        <div>
          <input placeholder='Full name' value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input placeholder='Role' value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} />
          <input placeholder='Phone' value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <input placeholder='Email' value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <input placeholder='4-6 digit code' value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
          <button onClick={genCode}>Generate</button>
          <input placeholder='Fee' value={form.fee} onChange={(e) => setForm({ ...form, fee: Number(e.target.value) })} />
          <label><input type='checkbox' checked={form.canEditFee} onChange={(e) => setForm({ ...form, canEditFee: e.target.checked })} /> Can edit fee</label>
          <button onClick={create}>Create</button>
        </div>
        <h4>Members</h4>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {members.map(m => (
            <div key={m.id} style={{ border: '1px solid #ddd', padding: 8 }}>
              <div>{m.name}</div>
